<?php
session_start();
error_reporting(1);
include("connection.php");
if(isset($_POST['log']))
{ if($_POST['id']=="" || $_POST['pwd']=="")
{ $err="fill your id and password first"; }
else 
{$d=mysql_query("select * from user where name='{$_POST['id']}' ");
$row=mysql_fetch_object($d);
$fid=$row->name;
$fpass=$row->pass; 
if($fid==$_POST['id'] && $fpass==$_POST['pwd'])
{$_SESSION['sid']=$_POST['id'];
header('location:home.php'); }
else { $er=" your password is not"; }}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Zay Shop - Contact</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">

    <!-- Load map styles -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />
<!--
    
TemplateMo 559 Zay Shop

https://templatemo.com/tm-559-zay-shop

-->
</head>

<body>


    	<h1 align="center">Electronics Shop</h1>
        <h2 align="center">Admin Log In</h2>
<!-- Start Contact -->
<div class="container py-5">
        <div class="row py-5">
            <form class="col-md-9 m-auto" method="post" role="form">
                
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputname">User Name</label>
                        <input type="text" class="form-control mt-1" id="id" name="id" placeholder="Enter User Name">
                    </div>
                   
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputpassword">Password</label>
                        <input type="text" class="form-control mt-1" id="pwd" name="pwd" placeholder="Enter Your Password">
                    </div>
                
                <div class="row">
                    <div class="col text-end mt-2">
                        <button type="submit"  name="log"  id="log" value="Log in" class="btn btn-success btn-lg px-3">Log In</button>
                    </div>
                </div>
            </form>
            <h2><?php echo $er;?></h2>
        </div>
    </div>
    <!-- End Contact -->


</body>
</html>