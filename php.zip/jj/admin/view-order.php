<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Electronics Shops</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
<!--
    
TemplateMo 559 Zay Shop

https://templatemo.com/tm-559-zay-shop

-->
   <!-- Start Script -->
   <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->
</head>
<body>

<<!-- Header -->
  <nav class="navbar navbar-expand-lg navbar-light shadow">
        <div class="container d-flex justify-content-between align-items-center">

            <a class="navbar-brand text-success logo h1 align-self-center" href="index.php">
                Electronics Shop
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="align-self-center collapse navbar-collapse flex-fill  d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
                <div class="flex-fill">
                    <ul class="nav navbar-nav d-flex justify-content-between mx-lg-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="home.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="insert.php">Insert</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="view-product.php">Product</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="view-order.php">Order</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="view-feedback.php">Feedback</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Log Out</a>
                        </li>
                    </ul>
                </div>
                </div>
            </div>

        </div>
</nav>
    <div id="tooplate_main">
		<br>
		<br>
    	<h2 align="center"> View Order form</h2>
		<br>
		<br>
       <table align="center" width="1000px" align="center">
					
					<tr style="text-align: center">
                        <th style="background-color:grey; border: solid black 1px"; width="100px" height="50px">ID:</th>					
						<th style="background-color:grey; border: solid black 1px"; width="100px" height="50px">Product NO:</th>
						<th style="background-color:grey; border: solid black 1px"; width="100px" height="50px">Price:</th>
						<th style="background-color:grey; border: solid black 1px"; width="100px" height="50px">Name:</th>
						<th style="background-color:grey; border: solid black 1px"; width="100px" height="50px">Phone:</th>
						<th style="background-color:grey; border: solid black 1px"; width="100px" height="50px">Address:</th>	
						<th style="background-color:grey; border: solid black 1px"; width="100px" height="50px">Order No:</th>						
					 </tr>	
					 <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from orders ");
						while($row=mysql_fetch_array($sel))
							{		
									$id=$row['ord_id'];					
									$prodno=$row['productno'];
									$price=$row['price'];
									$name=$row['name'];
									$phone=$row['phone'];
									$address=$row['address'];
									$ordno=$row['order_no'];
						?>
					 <tr style="text-align: center">
						
						<td  style="border: solid black 1px" ;  width="100px" height="50px"><?php echo $id; ?></td>
						<td  style="border: solid black 1px" ;  width="100px" height="50px"><?php echo $prodno; ?></td>
						<td  style="border: solid black 1px" ;  width="100px" height="50px"><?php echo $price; ?></td>
						<td  style="border: solid black 1px" ;  width="100px" height="50px"><?php echo $name; ?></td>
						<td  style="border: solid black 1px" ;  width="100px" height="50px"><?php echo $phone; ?></td>
						<td  style="border: solid black 1px" ;  width="100px" height="50px"><?php echo $address; ?></td>
						<td  style="border: solid black 1px" ;  width="100px" height="50px"><?php echo $ordno; ?></td>
						
						
												
					  </tr>			
					<?php				  
							}	
					?>
					</table>
       
        
        

        <div class="clear"></div>
    </div>
    <div style="display:none;" class="nav_up" id="nav_up"></div>
</div> <!-- END of tooplate_wrapper -->

<?php }  ?>


</body>
</html>