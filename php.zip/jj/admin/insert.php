<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<?php
error_reporting(1);
include("connection.php");
$img=$_FILES['img']['name'];
$prono=$_POST['t1'];
$price=$_POST['t2'];
if($_POST['sub'])
{$qry="INSERT INTO item(img,prod_no,price)VALUES('$img','$prono','$price')";
$result=mysql_query($qry) or die ("save items query fail.");
if($result)			
	   {mkdir("image/$i");
			move_uploaded_file($_FILES['img']['tmp_name'],"image/$i".$_FILES['img']['name']);	
  // move_uploaded_file($_FILES['file']['tmp_name'],"itempics/$itemno.jpg");
		
	    $err="<font size='+4'>Item Inserted Successfully</font>";
	
		}
	else
	 {
	   echo "item is not inserted";
	   }
	}  
	mysql_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Electronics Shops</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
<!--
    
TemplateMo 559 Zay Shop

https://templatemo.com/tm-559-zay-shop

-->
   <!-- Start Script -->
   <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->
</head>

<body>
       
        

        <div class="clear"></div>
    </div>
    <div style="display:none;" class="nav_up" id="nav_up"></div>
</div> <!-- END of tooplate_wrapper -->
<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-light shadow">
        <div class="container d-flex justify-content-between align-items-center">

            <a class="navbar-brand text-success logo h1 align-self-center" href="index.php">
                Electronics Shop
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="align-self-center collapse navbar-collapse flex-fill  d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
                <div class="flex-fill">
                    <ul class="nav navbar-nav d-flex justify-content-between mx-lg-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="home.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="insert.php">Insert</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="view-product.php">Product</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="view-order.php">Order</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="view-feedback.php">Feedback</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Log Out</a>
                        </li>
                    </ul>
                </div>
                </div>
            </div>

        </div>
    </nav>
</div> <!-- END of tooplate_footer_wrapper --><br>
    <div id="tooplate_main">
			 <div id="contact_form" class="col_2">
                <h1 align="center">Insert Image</h1>
                
				<h2><?php echo $err;?></h2>
            </div> 

			<!-- Start Contact -->
<div class="container py-5">
        <div class="row py-5">
            <form class="col-md-9 m-auto" method="post" role="form">

			        <div class="form-group col-md-6 mb-3">
                        <label for="inputname">Image:</label>
                        <input type="file" class="form-control mt-1" id="id" name="img" placeholder="Enter User Name">
                    </div>
                
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputname">Product Name: </label>
                        <input type="text" class="form-control mt-1" id="t1" name="t1" placeholder="Enter Your Product Name">
                    </div>
                   
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputpassword">Price:</label>
                        <input type="text" class="form-control mt-1" id="t2" name="t2" placeholder="Enter Product's Price">
                    </div>
                
                <div class="row">
                    <div class="col text-end mt-2">
                        <button type="submit"  name="sub" value="submit" class="btn btn-success btn-lg px-3">Submit</button>
                    </div>
                </div>
            </form>
            <h2><?php echo $er;?></h2>
        </div>
    </div>
    <!-- End Contact -->
       
        
        

        <div class="clear"></div>
    </div>
    <div style="display:none;" class="nav_up" id="nav_up"></div>
</div> <!-- END of tooplate_wrapper -->


<?php }  ?>
</body>
</html>