<?php
error_reporting(1);
session_start();
$i=$_REQUEST['img'];
$_SESSION['sid']=$_POST['id'];
include("connection.php");
$i=$_REQUEST['img'];
if($_POST['ord'])
{ 
$prodno=$_POST['prodno'];
$price=$_POST['price'];
$name=$_POST['nam'];
$phone=$_POST['pho'];
$add=$_POST['add'];
$ordno=ord.rand(100,500);
if(mysql_query("insert into orders(productno,price,name,phone,address,order_no) values('$prodno','$price','$name','$phone','$add','$ordno')"))
{
//echo "<script>location.href='ordersent.php?prod'</script>";
header("location:ordersent.php?order_no=$ordno");  }
else {$error= "user already exists";}}

?>
<?php
error_reporting(1);
$op=opendir("img");
while($file=readdir($op))
{
	 if($file!='.' && $file!='..')
	 {
	echo "<img src='img/$file' width='150px' height='150px'/> &nbsp;&nbsp;"; 
	 }
} 
 ?>



<!DOCTYPE html>
<html lang="en">

<head>
    <title> Electronics Shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<!--
    
TemplateMo 559 Zay Shop

https://templatemo.com/tm-559-zay-shop

-->
<link rel="apple-touch-icon" href="assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!-- Start Script -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->
</head>
<body style='background-color: lightgray;'>
    <div id="tooplate_main">
	
    	<div id="tooplate_content" class="left">
          <div id="comment_form">
            <h2 align="center">Order form</h2>
        <?php
			include("connection.php");
			$sel=mysql_query("select * from item  where img='$i' ");
			$mat=mysql_fetch_array($sel);
			
			
			?>
        
        </div>  
            
            
            
            
            
            
        </div> <!-- END of content -->
                
		
            
           
      </div>
        
      <div class="clear"></div>
    </div>
    <div style="display:none;" class="nav_up" id="nav_up"></div>
</div> <!-- END of tooplate_wrapper -->
<!-- Start Order -->
<div class="container py-5">
        <div class="row py-5">
            <form class="col-md-9 m-auto" method="post" role="form">
                
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputname">Product No </label>
                        <input type="text" class="form-control mt-1" id="prodno" name="prodno" value="<?php echo $mat['prod_no'];?>" placeholder="Enter Your Product No">
                    </div>
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputemail">Price</label>
                        <input type="text" class="form-control mt-1" id="price" name="price" value="<?php echo $mat['price'];?>" placeholder="Enter Your Price">
                    </div>
                
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputemail">Name</label>
                        <input type="text" class="form-control mt-1" id="nam" name="nam" placeholder="Enter Your Name">
                    </div>
                
                    
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputphone.no">Phone.No</label>
                        <input type="text" class="form-control mt-1" id="php" name="pho" placeholder="Enter Your Phone.No">
                    </div>
               
                    <div class="form-group col-md-6 mb-3">
                        <label for="inputaddress">Address</label>
                        <textarea class="form-control mt-1" id="add" name="add" rows="8" placeholder="Enter Your Adress"></textarea>
                    </div>
                
                <div class="row">
                    <div class="col text-end mt-2">
                        <button type="submit"  name="ord"  id="ord" value="sent order" class="btn btn-success btn-lg px-3">Sent Order</button>
                    </div>
                </div>
                <div class="row">
                    <div class="col text-end mt-2">
                        <button type="reset"  name="Cancle" value="Cancel" class="btn btn-success btn-lg px-3">Cancel</button>
                    </div>
                </div>
                <label><?php echo "<font color='red'>$error</font>";?></label>
            </form>
        </div>
    </div>
    <!-- End Register -->

</body>
</html>